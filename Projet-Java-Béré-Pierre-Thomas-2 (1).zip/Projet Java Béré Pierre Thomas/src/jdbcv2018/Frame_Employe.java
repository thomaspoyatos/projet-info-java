/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdbcv2018;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author Berenice
 */
public class Frame_Employe extends JFrame implements ActionListener{
    Connexion newconexion;
    JLabel lab = new JLabel("Vous voulez voir:");
    JButton tout= new JButton ("Tout");
    JButton adresse= new JButton ("Adresse");
    JButton nom= new JButton ("Nom");
    JButton numero= new JButton ("Numero");
    JButton prenom= new JButton ("Prenom");
    JButton tel= new JButton("Tel");
    JPanel boutonPane = new JPanel();
    JPanel pan=new JPanel();
    JLabel liste=new JLabel();
    
    public Frame_Employe(){
        
        this.setTitle("Employés");
        this.setSize(600, 400);
        this.setLocation(200, 100); 
        
        try{
        this.newconexion= new Connexion("hopital", "root", "");
        }catch(SQLException ex){
            System.out.println("Erreur de connexion à la base locale");
        }catch(ClassNotFoundException ex){   
        }
    
        tout.addActionListener(this);
        adresse.addActionListener(this);
        nom.addActionListener(this);
        numero.addActionListener(this);
        prenom.addActionListener(this);
        tel.addActionListener(this);
           
        boutonPane.add(lab);
        boutonPane.add(tout);
        boutonPane.add(adresse);
        boutonPane.add(nom);
        boutonPane.add(numero);
        boutonPane.add(prenom);
        boutonPane.add(tel);
        
      this.getContentPane().add(boutonPane, BorderLayout.NORTH);
      this.add(pan);
     
      this.setVisible(true);      
    } 
    
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == tout){
      try{
               
                ArrayList<String> list= newconexion.remplirChampsRequete("select * from employe" );
                pan.removeAll();
                for(String str_list : list){
                    JLabel lbl=new JLabel(str_list);
                    pan.add(lbl);
                }
                pan.repaint();
                pan.revalidate();
            } catch(SQLException ex){
                System.out.println("pb");
            }  
        }
        if (ae.getSource() == adresse){
      try{
               
                ArrayList<String> list= newconexion.remplirChampsRequete("select adresse from employe" );
                pan.removeAll();
                for(String str_list : list){
                    JLabel lbl=new JLabel(str_list);
                    pan.add(lbl);
                }
                pan.repaint();
                pan.revalidate();
            } catch(SQLException ex){
                System.out.println("pb");
            }  
        }
        if (ae.getSource() == nom ){
      try{
               
                ArrayList<String> list= newconexion.remplirChampsRequete("select nom from employe" );
                pan.removeAll();
                for(String str_list : list){
                    JLabel lbl=new JLabel(str_list);
                    pan.add(lbl);
                }
                pan.repaint();
                pan.revalidate();
            } catch(SQLException ex){
                System.out.println("pb");
            }  
        }
        if (ae.getSource() == numero){
      try{
               
                ArrayList<String> list= newconexion.remplirChampsRequete("select numero from employe" );
                pan.removeAll();
                for(String str_list : list){
                    JLabel lbl=new JLabel(str_list);
                    pan.add(lbl);
                }
                pan.repaint();
                pan.revalidate();
            } catch(SQLException ex){
                System.out.println("pb");
            }  
        }
        if (ae.getSource() == prenom){
      try{
               
                ArrayList<String> list= newconexion.remplirChampsRequete("select prenom from employe" );
                pan.removeAll();
                for(String str_list : list){
                    JLabel lbl=new JLabel(str_list);
                    pan.add(lbl);
                }
                pan.repaint();
                pan.revalidate();
            } catch(SQLException ex){
                System.out.println("pb");
            }  
        }
         if (ae.getSource() == tel){
      try{
               
                ArrayList<String> list= newconexion.remplirChampsRequete("select tel from employe" );
                pan.removeAll();
                for(String str_list : list){
                    JLabel lbl=new JLabel(str_list);
                    pan.add(lbl);
                }
                pan.repaint();
                pan.revalidate();
            } catch(SQLException ex){
                System.out.println("pb");
            }  
        }
    }
}
