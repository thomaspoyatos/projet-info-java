 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdbcv2018;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import javax.swing.JFrame;
import java.awt.GridLayout;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.Connection;
import java.awt.Graphics;
import java.awt.Image;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JPanel;
import jdk.nashorn.internal.ir.BreakNode;



/**
 *
 * @author Berenice
 */
public class Menu_Recherche extends JPanel implements ActionListener {
   
    JButton chambre;
    JButton doctor;
    JButton employe;
    JButton hospitalisation;
    JButton infirmier;
    JButton malade;
    JButton service;
    JButton soigne;
    JButton requete;
    Frame_Chambre c;
    Frame_Docteur d;
    Frame_Employe e;
    Frame_Hospitalisation h;
    Frame_Infirmier i;
    Frame_Malade m;
    Frame_Service se;
    Frame_Soigne so;
    Frame_Requests r;
    
    Connexion newconexion;

    public Menu_Recherche() {
       // super();
       
        this.setSize(400, 200);
        //Nous demandons maintenant à notre objet de se positionner au centre
        this.setLocation(35, 50);
       //On définit le layout à utiliser sur le content pane
       
        this.chambre = new JButton("Chambres");
        this.doctor = new JButton("Docteurs");
        this.employe = new JButton("Employés");
        this.hospitalisation = new JButton("Hospitalisation");
        this.infirmier = new JButton("Infirmiers");
        this.malade = new JButton("Malades");
        this.service = new JButton("Services");
        this.soigne = new JButton("Soignés");
        this.requete=new JButton("Requètes");
        
         try{
        this.newconexion= new Connexion("hopital", "root", "");
        }catch(SQLException ex){
            System.out.println("Erreur de connexion à la base locale");
        }catch(ClassNotFoundException ex){
            
        }

         //pour pouvoir interagir avec mon instance d'objet soit bouton connexion dans ce cas la
        chambre.addActionListener((ActionListener)this);
        doctor.addActionListener((ActionListener) this);
        employe.addActionListener((ActionListener) this);
        hospitalisation.addActionListener((ActionListener) this);
        infirmier.addActionListener((ActionListener) this);
        malade.addActionListener((ActionListener) this);
        service.addActionListener((ActionListener) this);
        soigne.addActionListener((ActionListener) this);
        requete.addActionListener((ActionListener) this);
         
        this.add(chambre);
        this.add(doctor);
        this.add(employe);
        this.add(hospitalisation);
        this.add(infirmier);
        this.add(malade);
        this.add(service);
        this.add(soigne);
        this.add(requete);
        c=new Frame_Chambre();
        d=new Frame_Docteur();
        e=new Frame_Employe();
        h=new Frame_Hospitalisation();
        i=new Frame_Infirmier();
        m=new Frame_Malade();
        se=new Frame_Service();
        so=new Frame_Soigne();
        r=new Frame_Requests();
        c.setVisible(false);
        d.setVisible(false);
        e.setVisible(false);
        h.setVisible(false);
        i.setVisible(false);
        m.setVisible(false);
        se.setVisible(false);
        so.setVisible(false);
        r.setVisible(false);
        
       this.setVisible(false);
       
    }
    
    public void actionPerformed(ActionEvent ae) {

        if (ae.getSource() == chambre) {  
          c.setVisible(true);
        }
    
        if (ae.getSource() == doctor) {
         /*this.removeAll();
         new Frame_Docteur();
         this.validate();*/
         d.setVisible(true);
        }
        
        if (ae.getSource() == employe) {
         /*this.removeAll();
         new Frame_Employe();
         this.validate();*/
         e.setVisible(true);
        }
         
        if (ae.getSource() == hospitalisation) {
         /*this.removeAll();
         new Frame_Hospitalisation();
         this.validate();*/
         h.setVisible(true);
        }
          
        if (ae.getSource() == infirmier) {
         /*this.removeAll();
         new Frame_Infirmier();
         this.validate();*/
         i.setVisible(true);
        }
           
        if (ae.getSource() == malade) {
         /*this.removeAll();
         new Frame_Malade();
         this.validate();*/
         m.setVisible(true);
        }
            
        if (ae.getSource() == service) {
         /*this.removeAll();
         new Frame_Service();
         this.validate();*/
         se.setVisible(true);
        }
             
        if (ae.getSource() == soigne) {
         /*this.removeAll();
         new Frame_Soigne();
         this.validate();*/
         so.setVisible(true);
        }
        if (ae.getSource() == requete) {
         /*this.removeAll();
         new Frame_Requests();
         this.validate();*/
         r.setVisible(true);
        }
    
    }
  
}
    

