/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdbcv2018;

import static com.sun.java.accessibility.util.AWTEventMonitor.addWindowListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JPanel;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 *
 * @author Berenice
 */
/*public class Menu_Stats extends JPanel implements ActionListener{
    
    

    public Menu_Stats() {
                addWindowListener(new WindowAdapter() {
                public void windowClosing(WindowEvent e) {
                dispose();
                System.exit(0);
                }
                
   
});
    
}

   
}*/
