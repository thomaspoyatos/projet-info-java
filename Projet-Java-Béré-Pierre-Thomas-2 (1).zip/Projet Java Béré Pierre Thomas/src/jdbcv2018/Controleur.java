/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdbcv2018;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
/**
 *
 * @author Berenice
 */
public class Controleur {
    
    public static void main(String[] args) throws SQLException,ClassNotFoundException, IOException {
        Menu_Connexion menu= new Menu_Connexion();
    }
    
}
