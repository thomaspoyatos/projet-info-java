/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdbcv2018;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author Berenice
 */
public class Frame_Soigne extends JFrame implements ActionListener{
        
    Connexion newconexion;
    JLabel lab = new JLabel("Vous voulez voir:");
    JButton tout= new JButton ("Tout");
    JButton no_docteur= new JButton ("No Docteur");
    JButton no_malade= new JButton ("No Malade");
    JPanel boutonPane = new JPanel();
    JPanel pan=new JPanel();
    JLabel liste=new JLabel();
    
    public Frame_Soigne(){
        this.setTitle("Soignés");
        this.setSize(600, 400);
        this.setLocation(300, 100);
        
        try{
        this.newconexion= new Connexion("hopital", "root", "");
        }catch(SQLException ex){
            System.out.println("Erreur de connexion à la base locale");
        }catch(ClassNotFoundException ex){   
        }
    
        tout.addActionListener(this);
        no_docteur.addActionListener(this);
        no_malade.addActionListener(this);
        
           
        boutonPane.add(lab);
        boutonPane.add(tout);
        boutonPane.add(no_docteur);
        boutonPane.add(no_malade);
       
      this.getContentPane().add(boutonPane, BorderLayout.NORTH);
      this.add(pan);
     
      this.setVisible(true);      
    } 
    
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == tout){
      try{
               
                ArrayList<String> list= newconexion.remplirChampsRequete("select * from soigne" );
                pan.removeAll();
                for(String str_list : list){
                    JLabel lbl=new JLabel(str_list);
                    pan.add(lbl);
                }
                pan.repaint();
                pan.revalidate();
            } catch(SQLException ex){
                System.out.println("pb");
            }  
        }
        if (ae.getSource() == no_docteur){
      try{
               
                ArrayList<String> list= newconexion.remplirChampsRequete("select no_docteur from soigne" );
                pan.removeAll();
                for(String str_list : list){
                    JLabel lbl=new JLabel(str_list);
                    pan.add(lbl);
                }
                pan.repaint();
                pan.revalidate();
            } catch(SQLException ex){
                System.out.println("pb");
            }  
        }
        if (ae.getSource() == no_malade ){
      try{
               
                ArrayList<String> list= newconexion.remplirChampsRequete("select no_malade from soigne" );
                pan.removeAll();
                for(String str_list : list){
                    JLabel lbl=new JLabel(str_list);
                    pan.add(lbl);
                }
                pan.repaint();
                pan.revalidate();
            } catch(SQLException ex){
                System.out.println("pb");
            }  
        }
        
    }
}
