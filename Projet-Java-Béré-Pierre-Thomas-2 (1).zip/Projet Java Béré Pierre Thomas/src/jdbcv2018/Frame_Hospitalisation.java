/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdbcv2018;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author Berenice
 */
public class Frame_Hospitalisation extends JFrame implements ActionListener{
        
    Connexion newconexion;
    JLabel lab = new JLabel("Vous voulez voir:");
    JButton tout= new JButton ("Tout");
    JButton code_service= new JButton ("Code Service");
    JButton lit= new JButton ("Lit");
    JButton no_chambre= new JButton ("No Chambre");
    JButton no_malade= new JButton ("No Malade");
    JPanel boutonPane = new JPanel();
    JPanel pan=new JPanel();
    JLabel liste=new JLabel();
    
    public Frame_Hospitalisation(){
        this.setTitle("Hospitalisations");
        this.setSize(600, 400);
        this.setLocation(200, 100); 
        
        try{
        this.newconexion= new Connexion("hopital", "root", "");
        }catch(SQLException ex){
            System.out.println("Erreur de connexion à la base locale");
        }catch(ClassNotFoundException ex){   
        }
    
        tout.addActionListener(this);
        code_service.addActionListener(this);
        lit.addActionListener(this);
        no_chambre.addActionListener(this);
        no_malade.addActionListener(this);
           
        boutonPane.add(lab);
        boutonPane.add(tout);
        boutonPane.add(code_service);
        boutonPane.add(lit);
        boutonPane.add(no_chambre);
        boutonPane.add(no_malade);
        
      this.getContentPane().add(boutonPane, BorderLayout.NORTH);
      this.add(pan);
     
      this.setVisible(true);      
    } 
    
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == tout){
      try{
               
                ArrayList<String> list= newconexion.remplirChampsRequete("select * from hospitalisation" );
                pan.removeAll();
                for(String str_list : list){
                    JLabel lbl=new JLabel(str_list);
                    pan.add(lbl);
                }
                pan.repaint();
                pan.revalidate();
            } catch(SQLException ex){
                System.out.println("pb");
            }  
        }
        if (ae.getSource() == code_service){
      try{
               
                ArrayList<String> list= newconexion.remplirChampsRequete("select code_service from hospitalisation" );
                pan.removeAll();
                for(String str_list : list){
                    JLabel lbl=new JLabel(str_list);
                    pan.add(lbl);
                }
                pan.repaint();
                pan.revalidate();
            } catch(SQLException ex){
                System.out.println("pb");
            }  
        }
        if (ae.getSource() == lit ){
      try{
               
                ArrayList<String> list= newconexion.remplirChampsRequete("select lit from hospitalisation" );
                pan.removeAll();
                for(String str_list : list){
                    JLabel lbl=new JLabel(str_list);
                    pan.add(lbl);
                }
                pan.repaint();
                pan.revalidate();
            } catch(SQLException ex){
                System.out.println("pb");
            }  
        }
        if (ae.getSource() == no_chambre){
      try{
               
                ArrayList<String> list= newconexion.remplirChampsRequete("select no_chambre from hospitalisation" );
                pan.removeAll();
                for(String str_list : list){
                    JLabel lbl=new JLabel(str_list);
                    pan.add(lbl);
                }
                pan.repaint();
                pan.revalidate();
            } catch(SQLException ex){
                System.out.println("pb");
            }  
        }
        if (ae.getSource() == no_malade){
      try{
               
                ArrayList<String> list= newconexion.remplirChampsRequete("select no_malade from hospitalisation" );
                pan.removeAll();
                for(String str_list : list){
                    JLabel lbl=new JLabel(str_list);
                    pan.add(lbl);
                }
                pan.repaint();
                pan.revalidate();
            } catch(SQLException ex){
                System.out.println("pb");
            }  
        }
    }
}
