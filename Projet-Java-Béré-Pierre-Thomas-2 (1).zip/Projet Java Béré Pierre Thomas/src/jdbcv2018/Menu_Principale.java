package jdbcv2018;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Berenice
 */
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.GridLayout;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

public class Menu_Principale extends JFrame implements ActionListener {

    JButton recherche;
    JButton maj;
    JButton stats;
    Menu_Recherche mrecherche;
    Connexion newconexion;
    CardLayout cl = new CardLayout();
    JPanel pan = new JPanel();
    
    public Menu_Principale(){
        this.setTitle("Bienvenue dans la BDD de l'Hopital");
        this.setSize(500, 350);
        //Nous demandons maintenant à notre objet de se positionner au centre
        this.setLocation(50, 50);
        //Termine le processus lorsqu'on clique sur la croix rouge
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel boutonPane = new JPanel();
        //On définit le layout à utiliser sur le content pane
        //this.setLayout(new GridLayout(3,0));
        this.recherche = new JButton("Recherche Information");
        this.maj = new JButton("Mettre à jour");
        this.stats = new JButton("Statistiques");
        try{
        this.newconexion= new Connexion("hopital", "root", "");
        }catch(SQLException ex){
            System.out.println("Erreur de connexion à la base locale");
        }catch(ClassNotFoundException ex){
            
        }
       
        recherche.addActionListener(this);
        maj.addActionListener(this);
        stats.addActionListener(this);
        
        boutonPane.add(recherche);
        boutonPane.add(maj);
        boutonPane.add(stats);
        mrecherche= new Menu_Recherche();
        pan.setVisible(false);
      this.add(boutonPane, BorderLayout.NORTH);
      this.add(mrecherche, BorderLayout.CENTER);
      this.add(pan,BorderLayout.CENTER);
      this.setVisible(true);
    }


    public void actionPerformed(ActionEvent ae){
        if(ae.getSource()==recherche){
            //pan.setBackground(Color.yellow);
           //this.setContentPane(new Menu_Recherche());
            mrecherche.setVisible(true);
            pan.setVisible(false);
           
        }
  
         if(ae.getSource()==maj){  
             pan.setVisible(true);
             mrecherche.setVisible(false);
             pan.setBackground(Color.ORANGE);
           /*try{
                ArrayList<String> list= newconexion.remplirChampsRequete("select * from docteur");
                for(String string: list){
                    System.out.println(string);
                }
            } catch(SQLException ex){
                System.out.println("pb");
            }*/
         }
        
          if(ae.getSource()==stats){
             pan.setBackground(Color.BLUE);
             /* try{
                ArrayList<String> list= newconexion.remplirChampsRequete("select * from docteur");
                for(String string: list){
                    System.out.println(string);
                }
            } catch(SQLException ex){
                System.out.println("pb");
            }*/
        }
}
}
 

 
