/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdbcv2018;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import org.omg.CORBA.SystemException;

/**
 *
 * @author Berenice
 */
public class Frame_Requests extends JFrame implements ActionListener {

    JButton r1;
    JButton r2;
    JButton r4;
    JButton r5;
    JButton r6;
    JButton r7;
    JButton r8;
    JPanel boutonPane = new JPanel();
    JPanel pan = new JPanel();
    JLabel liste = new JLabel();
    JLabel lattribut = new JLabel("Attribut(s):");
    JLabel ltable = new JLabel("Table(s):");
    JLabel l1 = new JLabel("Condition 1:");
    JLabel l2 = new JLabel("Condition 2:");
    JLabel l3 = new JLabel("Condition 3:");
    JLabel l4 = new JLabel("Condition 4:");
    JLabel moyenne=new JLabel("Moyenne de:");
    JLabel regroupe=new JLabel("Groupe par:");
    JTextField groupe =new JTextField(10);
    JTextField moy = new JTextField(10);
    JTextField attribut = new JTextField(10);
    JTextField table = new JTextField(10);
    JTextField requete1 = new JTextField(15);
    JTextField requete2 = new JTextField(15);
    JTextField requete3 = new JTextField(15);
    JTextField requete4 = new JTextField(15);
    JButton recherche = new JButton("Rechercher");
    JButton recherche2 = new JButton("Rechercher");
    JButton recherche4 = new JButton("Rechercher");
    JButton recherche5 = new JButton("Rechercher");
    JButton recherche6 = new JButton("Rechercher");
    JButton recherche7 = new JButton("Rechercher");
    JButton recherche8 = new JButton("Rechercher");

    //String s=table.getText();
    Connexion newconexion;

    public Frame_Requests() {

        this.setTitle("Les Requètes");
        this.setSize(900, 600);
        this.setLocation(300, 100);

        this.r1 = new JButton("1/ 1 condition");
        this.r2 = new JButton("2/3/ 2 conditions");
        this.r4 = new JButton("4/ Distinct 4 conditions");
        this.r5 = new JButton("Requete 5");
        this.r6 = new JButton("Requete 6");
        this.r7 = new JButton("Requete 7");
        this.r8 = new JButton("Requete 8");

        try {
            this.newconexion = new Connexion("hopital", "root", "");
        } catch (SQLException ex) {
            System.out.println("Erreur de connexion à la base locale");
        } catch (ClassNotFoundException ex) {
        }

        r1.addActionListener((ActionListener) this);
        r2.addActionListener((ActionListener) this);
        r4.addActionListener((ActionListener) this);
        r5.addActionListener((ActionListener) this);
        r6.addActionListener((ActionListener) this);
        r7.addActionListener((ActionListener) this);
        r8.addActionListener((ActionListener) this);

        boutonPane.add(r1);
        boutonPane.add(r2);
        boutonPane.add(r4);
        boutonPane.add(r5);
        boutonPane.add(r6);
        boutonPane.add(r7);
        boutonPane.add(r8);

        this.getContentPane().add(boutonPane, BorderLayout.NORTH);
        this.add(pan);

        this.setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {

        if (ae.getSource() == r1) {

            pan.removeAll();

            recherche.addActionListener(this);

            pan.add(lattribut);
            pan.add(attribut);
            pan.add(ltable);
            pan.add(table);
            pan.add(l1);
            pan.add(requete1);
            pan.add(recherche);

            pan.repaint();
            pan.revalidate();
        }

        if (ae.getSource() == recherche) {
            try {
                ArrayList<String> list = newconexion.remplirChampsRequete("select " + attribut.getText() + " from " + table.getText() + " where " + requete1.getText());
                pan.removeAll();
                for (String str_list : list) {
                    JLabel lbl = new JLabel(str_list);
                    pan.add(lbl);
                }
                pan.repaint();
                pan.revalidate();
            } catch (SQLException ex) {
                System.out.println("pb");
            }
        }

        if (ae.getSource() == r2) {
            pan.removeAll();

            recherche2.addActionListener(this);

            pan.add(lattribut);
            pan.add(attribut);
            pan.add(ltable);
            pan.add(table);
            pan.add(l1);
            pan.add(requete1);
            pan.add(l2);
            pan.add(requete2);
            pan.add(recherche2);

            pan.repaint();
            pan.revalidate();
        }

        if (ae.getSource() == recherche2) {
            try {

                ArrayList<String> list = newconexion.remplirChampsRequete("select " + attribut.getText() + " from " + table.getText() + " where " + requete1.getText() + " and " + requete2.getText());
                pan.removeAll();
                for (String str_list : list) {
                    JLabel lbl = new JLabel(str_list);
                    pan.add(lbl);
                }
                pan.repaint();
                pan.revalidate();
            } catch (SQLException ex) {
                System.out.println("pb");
            }
        }
 
        if (ae.getSource() == r4) {
            pan.removeAll();

            recherche4.addActionListener(this);

            pan.add(lattribut);
            pan.add(attribut);
            pan.add(ltable);
            pan.add(table);
            pan.add(l1);
            pan.add(requete1);
            pan.add(l2);
            pan.add(requete2);
            pan.add(l3);
            pan.add(requete3);
            pan.add(l4);
            pan.add(requete4);
            pan.add(recherche4);

            pan.repaint();
            pan.revalidate();
        }
        if (ae.getSource() == recherche4) {
            try {

                ArrayList<String> list = newconexion.remplirChampsRequete("select distinct " + attribut.getText() + " from " + table.getText() + " where " + requete1.getText() + " and " + requete2.getText()+" and "+requete3.getText()+" and "+requete4.getText());
                pan.removeAll();
                for (String str_list : list) {
                    JLabel lbl = new JLabel(str_list);
                    pan.add(lbl);
                }
                pan.repaint();
                pan.revalidate();
            } catch (SQLException ex) {
                System.out.println("pb");
            }
        }
        if (ae.getSource() == r5) {
            pan.removeAll();

            recherche5.addActionListener(this);
            pan.add(moyenne);
            pan.add(moy);
            pan.add(lattribut);
            pan.add(attribut);
            pan.add(ltable);
            pan.add(table);
            pan.add(regroupe);
            pan.add(groupe);
            pan.add(recherche5);
           

            pan.repaint();
            pan.revalidate();
        }
        if (ae.getSource() == recherche5) {
            try {

                ArrayList<String> list = newconexion.remplirChampsRequete("select "+attribut.getText()+", AVG("+moy.getText()+") from "+table.getText()+" group by "+groupe.getText());
                pan.removeAll();
                for (String str_list : list) {
                    JLabel lbl = new JLabel(str_list);
                    pan.add(lbl);
                }
                pan.repaint();
                pan.revalidate();
            } catch (SQLException ex) {
                System.out.println("pb");
            }
        }
        if (ae.getSource() == r6) {
            try {

                ArrayList<String> list = newconexion.remplirChampsRequete("select code_service,AVG(nb_lits) from chambre group by code_service right join service where service.batiment='A'");
                pan.removeAll();
                for (String str_list : list) {
                    JLabel lbl = new JLabel(str_list);
                    pan.add(lbl);
                }
                pan.repaint();
                pan.revalidate();
            } catch (SQLException ex) {
                System.out.println("pb");
            }
        }
        if (ae.getSource() == r7) {
            try {

                ArrayList<String> list = newconexion.remplirChampsRequete("select prenom, nom  from malade where mutuelle='MAAF'");
                pan.removeAll();
                for (String str_list : list) {
                    JLabel lbl = new JLabel(str_list);
                    pan.add(lbl);
                }
                pan.repaint();
                pan.revalidate();
            } catch (SQLException ex) {
                System.out.println("pb");
            }
        }
        if (ae.getSource() == r8) {
            try {

                ArrayList<String> list = newconexion.remplirChampsRequete("select prenom, nom  from malade where mutuelle='MAAF'");
                pan.removeAll();
                for (String str_list : list) {
                    JLabel lbl = new JLabel(str_list);
                    pan.add(lbl);
                }
                pan.repaint();
                pan.revalidate();
            } catch (SQLException ex) {
                System.out.println("pb");
            }
        }
    }
}
