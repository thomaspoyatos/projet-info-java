/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdbcv2018;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author Berenice
 */
public class Frame_Infirmier extends JFrame implements ActionListener {
     
    Connexion newconexion;
    JLabel lab = new JLabel("Vous voulez voir:");
    JButton tout= new JButton ("Tout");
    JButton code_service= new JButton ("Code Service");
    JButton numero= new JButton ("Numero");
    JButton rotation= new JButton ("Rotation");
    JButton salaire= new JButton ("Salaire");
    JPanel boutonPane = new JPanel();
    JPanel pan=new JPanel();
    JLabel liste=new JLabel();
    
    public Frame_Infirmier(){
        this.setTitle("Infirmiers");
        this.setSize(600, 400);
        this.setLocation(200, 100);
        
        try{
        this.newconexion= new Connexion("hopital", "root", "");
        }catch(SQLException ex){
            System.out.println("Erreur de connexion à la base locale");
        }catch(ClassNotFoundException ex){   
        }
    
        tout.addActionListener(this);
        code_service.addActionListener(this);
        numero.addActionListener(this);
        rotation.addActionListener(this);
        salaire.addActionListener(this);
           
        boutonPane.add(lab);
        boutonPane.add(tout);
        boutonPane.add(code_service);
        boutonPane.add(numero);
        boutonPane.add(rotation);
        boutonPane.add(salaire);
        
      this.getContentPane().add(boutonPane, BorderLayout.NORTH);
      this.add(pan);
     
      this.setVisible(true);      
    } 
    
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == tout){
      try{
               
                ArrayList<String> list= newconexion.remplirChampsRequete("select * from infirmier" );
                pan.removeAll();
                for(String str_list : list){
                    JLabel lbl=new JLabel(str_list);
                    pan.add(lbl);
                }
                pan.repaint();
                pan.revalidate();
            } catch(SQLException ex){
                System.out.println("pb");
            }  
        }
        if (ae.getSource() == code_service){
      try{
               
                ArrayList<String> list= newconexion.remplirChampsRequete("select code_service from infirmier" );
                pan.removeAll();
                for(String str_list : list){
                    JLabel lbl=new JLabel(str_list);
                    pan.add(lbl);
                }
                pan.repaint();
                pan.revalidate();
            } catch(SQLException ex){
                System.out.println("pb");
            }  
        }
        if (ae.getSource() == numero ){
      try{
               
                ArrayList<String> list= newconexion.remplirChampsRequete("select numero from infirmier" );
                pan.removeAll();
                for(String str_list : list){
                    JLabel lbl=new JLabel(str_list);
                    pan.add(lbl);
                }
                pan.repaint();
                pan.revalidate();
            } catch(SQLException ex){
                System.out.println("pb");
            }  
        }
        if (ae.getSource() == rotation){
      try{
               
                ArrayList<String> list= newconexion.remplirChampsRequete("select rotation from infirmier" );
                pan.removeAll();
                for(String str_list : list){
                    JLabel lbl=new JLabel(str_list);
                    pan.add(lbl);
                }
                pan.repaint();
                pan.revalidate();
            } catch(SQLException ex){
                System.out.println("pb");
            }  
        }
        if (ae.getSource() == salaire){
      try{
               
                ArrayList<String> list= newconexion.remplirChampsRequete("select salaire from infirmier" );
                pan.removeAll();
                for(String str_list : list){
                    JLabel lbl=new JLabel(str_list);
                    pan.add(lbl);
                }
                pan.repaint();
                pan.revalidate();
            } catch(SQLException ex){
                System.out.println("pb");
            }  
        }
    }   
}
