/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdbcv2018;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author Berenice
 */
public class Frame_Docteur extends JFrame implements ActionListener{
    
    Connexion newconexion;
    JLabel lab = new JLabel("Vous voulez voir:");
    JButton tout= new JButton ("Tout");
    JButton numero= new JButton ("Numéro");
    JButton specialte= new JButton ("Specialité");
    JPanel boutonPane = new JPanel();
    JPanel pan=new JPanel();
    JLabel liste=new JLabel();
    
    public Frame_Docteur(){
        this.setTitle("Docteurs");
        this.setSize(600, 400);
        this.setLocation(200, 100); 
        
        try{
        this.newconexion= new Connexion("hopital", "root", "");
        }catch(SQLException ex){
            System.out.println("Erreur de connexion à la base locale");
        }catch(ClassNotFoundException ex){   
        }
    
        tout.addActionListener(this);
        numero.addActionListener(this);
        specialte.addActionListener(this);
           
        boutonPane.add(lab);
        boutonPane.add(tout);
        boutonPane.add(numero);
        boutonPane.add(specialte);
      
      this.getContentPane().add(boutonPane, BorderLayout.NORTH);
      this.add(pan);
     
      this.setVisible(true);      
    } 
    
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == tout){
      try{
               
                ArrayList<String> list= newconexion.remplirChampsRequete("select * from docteur" );
                pan.removeAll();
                for(String str_list : list){
                    JLabel lbl=new JLabel(str_list);
                    pan.add(lbl);
                }
                pan.repaint();
                pan.revalidate();
            } catch(SQLException ex){
                System.out.println("pb");
            }  
        }
        if (ae.getSource() == numero){
      try{
               
                ArrayList<String> list= newconexion.remplirChampsRequete("select numero from docteur" );
                pan.removeAll();
                for(String str_list : list){
                    JLabel lbl=new JLabel(str_list);
                    pan.add(lbl);
                }
                pan.repaint();
                pan.revalidate();
            } catch(SQLException ex){
                System.out.println("pb");
            }  
        }
        if (ae.getSource() == specialte){
      try{
               
                ArrayList<String> list= newconexion.remplirChampsRequete("select specialite from docteur" );
                pan.removeAll();
                for(String str_list : list){
                    JLabel lbl=new JLabel(str_list);
                    pan.add(lbl);
                }
                pan.repaint();
                pan.revalidate();
            } catch(SQLException ex){
                System.out.println("pb");
            }  
        }
       
    }
}
