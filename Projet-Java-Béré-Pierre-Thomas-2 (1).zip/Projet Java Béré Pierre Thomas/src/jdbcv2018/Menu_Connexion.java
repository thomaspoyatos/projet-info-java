package jdbcv2018;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Berenice
 */

import javax.swing.JFrame;
import java.awt.GridLayout;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.Connection;
import java.awt.Graphics;
import java.awt.Image;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JPanel;

public class Menu_Connexion extends JFrame implements ActionListener {

    JButton connexion;
    JTextField utilisateur;
    JPasswordField mdp;
    JLabel util, password;

    Connexion newconexion;
    Menu_Principale principale;

    public Menu_Connexion() throws IOException {
        this.setTitle("Connexion à la BDD de l'Hopital");
        this.setSize(500, 100);
        //Nous demandons maintenant à notre objet de se positionner au centre
        this.setLocation(50, 50);
        //Termine le processus lorsqu'on clique sur la croix rouge
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel pan = new JPanel();

        //On définit le layout à utiliser sur le content pane
        this.setLayout(new GridLayout(1, 0));
        
        this.utilisateur = new JTextField(10);
        this.mdp = new JPasswordField(10);
        this.util = new JLabel("Identifiant");
        this.password = new JLabel("Mot de passe");
        this.connexion = new JButton("Connexion");

        pan.add(util);
        pan.add(utilisateur);
        pan.add(password);
        pan.add(mdp);
        pan.add(connexion);

        //pour pouvoir interagir avec mon instance d'objet soit bouton connexion dans ce cas la
        connexion.addActionListener(this);
        this.setContentPane(pan);  

        this.pack();
        this.setVisible(true);

    }

    public void actionPerformed(ActionEvent ae) {

        if (ae.getSource() == connexion) {
            try {
                this.newconexion = new Connexion("hopital", utilisateur.getText(), String.valueOf(mdp.getPassword()));
                principale=new Menu_Principale();
            } catch (SQLException ex) {
                System.out.println("Pas pu se connecter à la base locale");
            } catch (ClassNotFoundException ex) {

            }
        }
    }

}

